module.exports = require('./lib/ObjectPath.js').ObjectPath;
