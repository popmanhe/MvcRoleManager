﻿'use strict';
; (function () {
    var app = angular.module('RoleManager', ['ui.bootstrap', 'ui.router']);
})();